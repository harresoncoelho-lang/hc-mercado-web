import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import inventory as inv


class InventoryGuards(unittest.TestCase):
    def test_manual_remote_guard_precedes_any_subprocess(self):
        with patch.dict(inv.os.environ, {}, clear=True), patch.object(inv.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, "remote_actions_only"):
                inv.main()
            run.assert_not_called()

    def test_exact_package_and_tamper(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            files = {}
            for name in inv.ALLOWED - {"package-manifest.json"}:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"fixture")
                files[name] = hashlib.sha256(b"fixture").hexdigest()
            (root / "package-manifest.json").write_text(json.dumps({"files": files}))
            with patch.object(inv, "DUMP_SHA", files[inv.DUMP]), patch.object(inv, "DUMP_BYTES", 7):
                inv.validate_package(root, list(inv.ALLOWED))
                with self.assertRaisesRegex(ValueError, "package_allowlist"):
                    inv.validate_package(root, list(inv.ALLOWED) + [".env"])
                (root / inv.DUMP).write_bytes(b"changed")
                with self.assertRaisesRegex(ValueError, "package_integrity"):
                    inv.validate_package(root, list(inv.ALLOWED))

    def test_private_and_manual_guards_precede_any_subprocess(self):
        with tempfile.TemporaryDirectory() as directory:
            event_path = Path(directory) / "event.json"
            environment = {"GITHUB_ACTIONS": "true", "GITHUB_EVENT_PATH": str(event_path),
                           "GITHUB_EVENT_NAME": "workflow_dispatch"}
            event_path.write_text(json.dumps({"repository": {"private": False}}))
            with patch.dict(inv.os.environ, environment, clear=True), patch.object(inv.subprocess, "run") as run:
                with self.assertRaisesRegex(ValueError, "private_repository_required"):
                    inv.main()
                run.assert_not_called()
            event_path.write_text(json.dumps({"repository": {"private": True}}))
            environment["GITHUB_EVENT_NAME"] = "push"
            with patch.dict(inv.os.environ, environment, clear=True), patch.object(inv.subprocess, "run") as run:
                with self.assertRaisesRegex(ValueError, "manual_dispatch_required"):
                    inv.main()
                run.assert_not_called()

    def test_container_configuration_fails_closed(self):
        args = ["--list", "/input/ficticio.dump"]
        data = {"HostConfig": {"NetworkMode": "none", "ReadonlyRootfs": True, "Privileged": False,
                               "CapDrop": ["ALL"], "SecurityOpt": ["no-new-privileges"]},
                "Config": {"User": "65534:65534", "Entrypoint": ["pg_restore"], "Cmd": args},
                "Mounts": [{"Destination": "/input", "RW": False}]}
        inv.validate_container(data, args)
        for key, value in [("NetworkMode", "bridge"), ("ReadonlyRootfs", False), ("Privileged", True)]:
            altered = copy.deepcopy(data)
            altered["HostConfig"][key] = value
            with self.assertRaisesRegex(ValueError, "container_isolation"):
                inv.validate_container(altered, args)
        data["Mounts"][0]["RW"] = True
        with self.assertRaisesRegex(ValueError, "container_isolation"):
            inv.validate_container(data, args)

    def test_command_never_connects_or_skips_acl(self):
        args = ["--schema-only", "--file=-", "/input/ficticio.dump"]
        command = inv.create_command("/tmp/input", args)
        self.assertIn("none", command)
        self.assertIn("pg_restore", command)
        self.assertIn(inv.IMAGE, command)
        self.assertTrue(command[-3:] == args)
        for flag in ("--dbname", "--clean", "--no-owner", "--no-acl", "--no-comments"):
            self.assertNotIn(flag, command)

    def test_toc_counts_entries_not_header(self):
        self.assertEqual(len(inv.toc_entries("; TOC Entries: 812\n1; 0 0 EXTENSION - plpgsql\n2; 0 0 ACL public x\n")), 2)


if __name__ == "__main__":
    unittest.main()
