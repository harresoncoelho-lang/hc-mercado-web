import copy
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import restore as r


class RestoreGuards(unittest.TestCase):
    def test_local_execution_rejected_before_commands(self):
        with patch.dict(r.os.environ, {}, clear=True), patch.object(r.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, "remote_manual_only"):
                r.main()
            run.assert_not_called()

    def test_baseline_and_role_preparation_preserve_real_roles(self):
        path = Path(__file__).with_name("baseline.json")
        self.assertEqual(r.digest(path), r.BASELINE_SHA)
        baseline = json.loads(path.read_text())
        self.assertEqual([len(baseline[k]) for k in ("tables", "roles", "memberships", "default_acl")], [40, 29, 21, 12])
        text = r.role_sql(baseline)
        self.assertIn('CREATE ROLE "postgres" WITH NOSUPERUSER', text)
        self.assertIn('ALTER ROLE "supabase_admin" WITH SUPERUSER', text)
        self.assertIn('SET "session_preload_libraries" TO \'supautils, safeupdate\'', text)
        self.assertNotIn("PASSWORD", text)
        self.assertNotIn('CREATE ROLE "pg_monitor"', text)
        self.assertEqual(text.count("GRANTED BY supabase_admin;"), 21)
        self.assertIn('service_role=X/supabase_admin', baseline["kit_acl"]["functions"][1]["acl"])

    def test_schema_comparison_ignores_only_section_order_and_psql_guard(self):
        first = "--\n-- Name: f(); Type: FUNCTION; Schema: public; Owner: supabase_admin\n--\nCREATE FUNCTION public.f() RETURNS int LANGUAGE sql AS $$ SELECT 1 $$;\n"
        second = "--\n-- Name: TABLE t; Type: ACL; Schema: public; Owner: supabase_admin\n--\nGRANT SELECT ON public.t TO authenticated;\n"
        before = "\\restrict Ab123\n" + first + second + "\n--\n-- PostgreSQL database dump complete\n--\n\\unrestrict Ab123\n"
        after = "\\restrict C456\n" + second + first + "\n--\n-- PostgreSQL database dump complete\n--\n\\unrestrict C456\n"
        self.assertEqual(r.canonical_schema(before), r.canonical_schema(after))
        self.assertNotEqual(r.canonical_schema(before), r.canonical_schema(after.replace("SELECT 1", "SELECT 2")))
        self.assertNotEqual(r.canonical_schema(before), r.canonical_schema(after.replace("GRANT SELECT", "GRANT ALL")))
        with self.assertRaisesRegex(ValueError, "duplicate_schema_section"):
            r.canonical_schema(first + first)

    def test_container_has_only_private_scratch_and_readonly_input(self):
        source = "/repo/input"
        data = {"HostConfig": {"NetworkMode": "none", "ReadonlyRootfs": True, "Privileged": False,
                               "CapDrop": ["ALL"], "SecurityOpt": ["no-new-privileges"], "PortBindings": {},
                               "Tmpfs": {"/qa": "rw,nosuid,noexec,size=512m,mode=1777", "/tmp": "rw,nosuid,noexec,size=64m,mode=1777"}},
                "Config": {"User": "postgres", "Entrypoint": ["/bin/bash"], "Cmd": ["-ceu", r.START]},
                "Mounts": [{"Type": "bind", "Source": source, "Destination": "/input", "RW": False}]}
        r.verify_container(data, source)
        for key, value in [("NetworkMode", "bridge"), ("ReadonlyRootfs", False), ("Privileged", True), ("Tmpfs", {"/etc": "rw"})]:
            changed = copy.deepcopy(data)
            changed["HostConfig"][key] = value
            with self.assertRaisesRegex(ValueError, "container_isolation"):
                r.verify_container(changed, source)
        data["Mounts"][0]["RW"] = True
        with self.assertRaisesRegex(ValueError, "container_isolation"):
            r.verify_container(data, source)
        command = r.create_command(source)
        self.assertIn("--no-healthcheck", command)
        self.assertNotIn("--publish", command)
        self.assertNotIn("--privileged", command)

    def test_acl_order_does_not_hide_privilege_changes(self):
        baseline = json.loads(Path(__file__).with_name("baseline.json").read_text())["kit_acl"]
        reordered = copy.deepcopy(baseline)
        reordered["table"]["acl"] = "{" + ",".join(reversed(reordered["table"]["acl"][1:-1].split(","))) + "}"
        self.assertEqual(r.normalize_kit(baseline), r.normalize_kit(reordered))
        reordered["table"]["acl"] = reordered["table"]["acl"].replace("authenticated=r/", "authenticated=arwdDxt/")
        self.assertNotEqual(r.normalize_kit(baseline), r.normalize_kit(reordered))

    def test_timeout_preserves_partial_stdout_and_stderr(self):
        error = subprocess.TimeoutExpired(["fixture"], 2, output=b"partial stdout", stderr=b"partial stderr")
        with tempfile.TemporaryDirectory() as directory, patch.object(r.subprocess, "run", side_effect=error):
            output = Path(directory)
            with self.assertRaises(subprocess.TimeoutExpired):
                r.run_captured(["fixture"], output, timeout=2, failure_filename="failure-server_start.txt")
            self.assertEqual((output / "failure-server_start.txt").read_bytes(), b"partial stdout")
            self.assertEqual((output / "failure-server_start.txt.stderr").read_bytes(), b"partial stderr")
            proof = json.loads((output / "failure-server_start.txt.capture.json").read_text())
            self.assertTrue(proof["partial_timeout"])
            self.assertEqual(proof["timeout_seconds"], 2)

    def test_stopped_container_keeps_initdb_error_in_bounded_docker_log(self):
        results = [SimpleNamespace(returncode=0, stdout=b"x" * 70000, stderr=b"initdb failed"),
                   SimpleNamespace(returncode=1, stdout=b"", stderr=b"container is not running")]
        with tempfile.TemporaryDirectory() as directory, patch.object(r.subprocess, "run", side_effect=results) as run:
            output = Path(directory)
            evidence = r.capture_diagnostics("a" * 64, output)
            self.assertEqual((output / "diagnostic-docker.txt").stat().st_size, 65536)
            self.assertEqual((output / "diagnostic-docker.txt.stderr").read_bytes(), b"initdb failed")
            self.assertEqual(evidence["initdb"]["exit_code"], 1)
            self.assertEqual(run.call_args_list[0].args[0][:4], ["docker", "logs", "--tail", "100"])
            self.assertIn("|| { cat /qa/initdb.log >&2; exit 1; }", r.START)

    def test_diagnostic_timeout_keeps_partial_output_and_continues(self):
        results = [subprocess.TimeoutExpired(["docker"], 10, output=b"available log", stderr=b""),
                   SimpleNamespace(returncode=0, stdout=b"initialization detail", stderr=b"")]
        with tempfile.TemporaryDirectory() as directory, patch.object(r.subprocess, "run", side_effect=results):
            output = Path(directory)
            evidence = r.capture_diagnostics("a" * 64, output)
            self.assertEqual(evidence["docker"]["error"], "TimeoutExpired")
            self.assertEqual((output / "diagnostic-docker.txt").read_bytes(), b"available log")
            self.assertEqual((output / "diagnostic-initdb.txt").read_bytes(), b"initialization detail")


if __name__ == "__main__":
    unittest.main()
