# Restauração lógica fictícia — candidato para revisão

Preparado em 01/11/2026; **nenhum SQL, servidor, Docker local ou job desta restauração foi executado na preparação**. O inventário remoto anterior foi aprovado no run `41339162377`, commit `c08feeabe25ff3d726e9373b4d1a92147a99885f`: origem, pg_dump e cliente 17.11; 812 entradas selecionadas de 817 entradas totais do cabeçalho.

## Escopo mínimo e origem

Usar o mesmo dump fictício de 505.274 bytes e SHA256 `30456520f2b52f3e72ed79f57a7c3fea9f51b688ecd1753b504309393f47144c`. O snapshot anterior à correção de ACL foi normalizado em `baseline.json`: 40 tabelas (30 public, 10 Storage), 29 roles sem senhas, 21 memberships, 12 default ACLs e os objetos do kit. SHA256 do snapshot original: `f7a111357f7db4af3e849c8ffdba69e6e63ef409cee98c403e2ff70b87b95419`. OIDs foram traduzidos por nomes; namespaces vêm do TOC, mais o namespace public predefinido 2200. Ordem de ACL não altera sua semântica e é normalizada; privilégios/grantors não são retirados.

O dump declara pg_trgm. As referências a pg_cron/pg_net são corpos de funções de concessão; não há criação dessas extensões nem event triggers anexados, FDWs, publicações ou assinaturas no TOC. A baseline do papel authenticator exige bibliotecas reais `supautils, safeupdate`, motivo para não usar a imagem vanilla e não criar stubs. Funções existentes do dump permanecem exatamente como estavam, inclusive código de suporte de extensões não ativadas.

Imagem derivada da **mesma tag do Compose fictício**: `public.ecr.aws/supabase/postgres:17.11.0.004`, fixada no manifesto linux/amd64 `sha256:e85bc10ac5b141223b289e1e8dc8d448cf3df92501917149db0366b9c5aaf053`; config OCI `sha256:c4be96218454e68421a29c712e1a83c7a9fe186208c725d8bb2ebb474e2042f2`. Metadados públicos consultados sem baixar layers: 29 camadas, 367.717.338 bytes comprimidos, sem VOLUME declarado. O digest atual não foi demonstrado como idêntico ao image ID local histórico; compatibilidade é verificada pelo servidor, bibliotecas, restore e comparações. A versão 17.11 corresponde ao próprio dump fictício; não é afirmação sobre produção.

## Execução remota proposta

O workflow novo é manual, privado, com timeout de dez minutos e a mesma concorrência exclusiva do inventário. Não roda no push e não publica site. Adiciona ao repositório existente apenas `.github/workflows/restauracao.yml` e quatro arquivos em `restauracao/`; conserva os seis arquivos do inventário, seus hashes e o dump. Uploader e disparo ficam para a coordenação após revisão do candidato, saldo e bloqueio de cobrança adicional. Nenhuma credencial nova, login, serviço pago ou serviço HTTP é exigido.

O container substitui o entrypoint da imagem. Portanto não executa automaticamente as migrações Supabase ou o bootstrap da imagem. Inicia `initdb` vazio como usuário Linux postgres, com superuser SQL supabase_admin, e usa apenas Unix socket em `/qa`. Rede `none`, nenhuma porta, root filesystem somente leitura, capacidades removidas, input somente leitura e tmpfs efêmeros em `/qa` e `/tmp`. Não há volume persistente. Host authentication é rejeitada; local trust vale somente dentro desse container isolado, sem senha de origem. As bibliotecas são as da imagem real. Os defaults globais da distribuição não são tratados como backup da configuração original.

O preflight exige servidor 17.11 (mesma versão da origem comprovada), pg_trgm disponível e arquivos das duas bibliotecas. Prepara roles/atributos/config/memberships da baseline, sem passwords, e cria banco vazio `licitaplena_restore`. O role postgres conserva NOSUPERUSER; supabase_admin conserva SUPERUSER. O dump é restaurado uma vez, com `--exit-on-error --single-transaction`, sem `--clean`, `--no-owner`, `--no-acl`, lista filtrada ou correção posterior.

Depois compara:

- Esquema extraído do próprio dump versus pg_dump do destino: seções por identidade/owner, conservando SQL, ACLs, comentários e corpos de funções. Normaliza somente ordem das seções e comandos aleatórios `\\restrict`/`\\unrestrict` do cliente. Divergência interrompe para diagnóstico, sem ampliar filtros automaticamente.
- Contagens e o mesmo fingerprint MD5 de linhas JSONB ordenadas nas 40 tabelas, usando a receita original. SHA256 verifica o arquivo fonte; MD5 aqui reproduz o detector de alterações da baseline.
- Atributos e configurações de 29 roles, 21 memberships com grantor/flags e 12 default ACLs, por nomes.
- Owner, RLS e ACL do kit **antes da correção**, incluindo EXECUTE de service_role no trigger. Não aplica o ajuste aprovado posterior durante a prova de recuperação.
- Nova conexão local como authenticator, para comprovar que suas bibliotecas configuradas realmente carregam. Isso não é homologação de Auth HTTP.

Relatórios, schemas e resultados são artefatos privados por um dia. O log público do job não recebe SQL ou resultados de tabelas; stderr de falhas pode permanecer no artefato privado para revisão. Não há impressão de senha/token. O container é removido no finally; falha na remoção impede declarar sucesso. Timeout global/encerramento abrupto pode impedir finally/upload; o runner hospedado continua efêmero, e a coordenação deve verificar o término real do job.

Antes da remoção, captura privadamente as últimas 100 linhas do log Docker e o final de `/qa/initdb.log`, limitando cada stream salvo a 65.536 bytes. Se initdb falhar, seu log é emitido no stderr do container antes de sair, pois o tmpfs não persiste após a parada. Timeouts de subprocesso preservam stdout/stderr parciais com identificação explícita de captura incompleta. O relatório distingue criação, inspeção de isolamento, início e prontidão do servidor. Esses diagnósticos não alteram opções de isolamento, restauração ou comparação.

## Limites que permanecem

Os dados das 27 tabelas Auth presentes no TOC não têm baseline completa de contagens/hashes; são restaurados pelo dump, mas não certificados pela comparação das 40 tabelas. O valor da sequência Auth `refresh_tokens_id_seq` também não tem comparação com baseline; sua definição estrutural participa do comparador de esquema, seu valor não. Senhas de roles não são copiadas. Não há serviços GoTrue/PostgREST/Storage HTTP, login comercial, SMTP, API ou teste de aplicação nesta rodada.

Há cinco registros antigos de storage.objects e um bucket; os bytes correspondentes não acompanham o dump. Sua restauração continua pendente. Nenhum dos PDFs reais de produção será enviado. Configuração completa de cluster, collation original, versões históricas de cada biblioteca, backups físicos e RPO/RTO de produção não são certificados por este ensaio. O resultado poderá provar somente restauração e comparação do recorte fictício declarado; não libera produção nem equivale ao SaaS completo homologado.

Fontes públicas: [Dockerfile da tag usada](https://github.com/supabase/postgres/blob/17.11.0.004/Dockerfile-17), [pg_restore PostgreSQL 17](https://www.postgresql.org/docs/17/app-pgrestore.html). Inventário e snapshot anteriores são preservados sem alteração.
